
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))

import streamlit as st, pandas as pd, numpy as np, matplotlib.pyplot as plt, plotly.express as px, shap, json
from io import BytesIO
from datetime import date
from sklearn.preprocessing import LabelEncoder

from src.config import DEFAULT_MODEL_PATH, DEFAULT_PREPROCESSOR_PATH, DEFAULT_META_PATH, DATA_DIR, MODELS_DIR, REPORTS_DIR
from src.utils import load_joblib, load_json, save_joblib, save_json
from src.data_prep import split_features_target, detect_column_types, build_preprocessor, infer_task, train_val_split
from src.train import choose_models
from src.studysync.storage import add_entry, list_entries, clear_all, DEFAULT_PATH as SS_PATH, save as ss_save
from src.studysync.analytics import as_dataframe

st.set_page_config(page_title="Student Success Suite", layout="wide")
st.title("🎓 Student Success Suite")
st.caption("Predictive Analytics + StudySync Tracker")

tab1, tab2 = st.tabs(["🔮 Predictive Analytics", "📚 StudySync"])

with tab1:
    st.header("Predictive Analytics Platform")
    uploaded = st.file_uploader("Upload CSV", type=["csv"], key="pred_upload")
    df = None
    if uploaded is not None:
        df = pd.read_csv(uploaded); st.success(f"Loaded dataset with shape {df.shape}")
    else:
        if st.button("Load sample dataset", key="load_sample_pred"):
            sample_path = DATA_DIR / "sample_students.csv"
            if not sample_path.exists(): st.warning("Generate sample via: python src/sample_data_generator.py")
            else: df = pd.read_csv(sample_path); st.session_state["df_pred"]=df
        df = st.session_state.get("df_pred")

    if df is not None:
        st.dataframe(df.head(20), use_container_width=True)
        target = st.selectbox("Target", options=df.columns, key="pred_target")
        task_choice = st.selectbox("Task", options=["auto","classification","regression"], index=0, key="pred_task")
        X = df.drop(columns=[target]); y = df[target]
        task = infer_task(y) if task_choice=="auto" else task_choice

        # Option A: label-encode object targets for classification
        label_mapping=None
        if task=="classification" and (y.dtype=="O" or str(y.dtype).startswith("category")):
            le = LabelEncoder(); y = pd.Series(le.fit_transform(y), index=y.index)
            label_mapping = {int(i): cls for i, cls in enumerate(le.classes_)}

        num_cols, cat_cols = detect_column_types(X)
        st.markdown(f"**Detected:** {len(num_cols)} numeric, {len(cat_cols)} categorical columns")
        test_size = st.slider("Test size", 0.1, 0.4, 0.2, 0.05)

        if st.button("🚀 Train & Evaluate", key="pred_train"):
            preprocessor = build_preprocessor(num_cols, cat_cols)
            models = choose_models(task)
            from sklearn.pipeline import Pipeline
            from sklearn.model_selection import cross_val_score
            X_train, X_test, y_train, y_test = train_val_split(X, y, test_size=test_size, stratify=(task=="classification"))
            cv_results=[]; best_name=None; best_score=-np.inf; best_pipe=None
            for name, model in models.items():
                pipe = Pipeline([("prep", preprocessor), ("model", model)])
                scoring = "f1_macro" if task=="classification" else "r2"
                scores = cross_val_score(pipe, X_train, y_train, cv=5, scoring=scoring)
                cv_results.append({"model":name, "cv_mean":float(scores.mean()), "cv_std":float(scores.std())})
                if scores.mean()>best_score: best_name, best_score, best_pipe = name, scores.mean(), pipe
            best_pipe.fit(X_train, y_train)
            MODELS_DIR.mkdir(exist_ok=True, parents=True)
            save_joblib(best_pipe.named_steps["prep"], DEFAULT_PREPROCESSOR_PATH)
            save_joblib(best_pipe.named_steps["model"], DEFAULT_MODEL_PATH)
            meta = {"task":task,"target":target,"best_model":best_name,"feature_groups":{"numeric":num_cols,"categorical":cat_cols},"label_mapping":label_mapping}
            save_json(meta, DEFAULT_META_PATH)
            st.success(f"Best model: **{best_name}** (CV mean={best_score:.3f})")
            st.write(pd.DataFrame(cv_results).sort_values("cv_mean", ascending=False))

            from sklearn.metrics import accuracy_score, f1_score, r2_score, mean_absolute_error, mean_squared_error, confusion_matrix, classification_report
            y_pred = best_pipe.predict(X_test)
            if task=="classification":
                st.metric("Accuracy", f"{accuracy_score(y_test,y_pred):.3f}")
                st.metric("F1 Macro", f"{f1_score(y_test,y_pred,average='macro'):.3f}")
                cm = confusion_matrix(y_test,y_pred)
                st.plotly_chart(px.imshow(cm, text_auto=True, title="Confusion Matrix"), use_container_width=True)
                st.text("Classification report")
                st.code(classification_report(y_test,y_pred))
            else:
                r2=r2_score(y_test,y_pred); mae=mean_absolute_error(y_test,y_pred); rmse=mean_squared_error(y_test,y_pred,squared=False)
                c1,c2,c3=st.columns(3); c1.metric("R²", f"{r2:.3f}"); c2.metric("MAE", f"{mae:.3f}"); c3.metric("RMSE", f"{rmse:.3f}")
                st.plotly_chart(px.scatter(x=y_test, y=y_pred, labels={"x":"Actual","y":"Predicted"}, title="Actual vs Predicted"), use_container_width=True)

            st.subheader("🧠 SHAP (global)")
            try:
                preproc = best_pipe.named_steps["prep"]; model = best_pipe.named_steps["model"]; Xp = preproc.transform(X_train)
                try:
                    explainer = shap.TreeExplainer(model); shap_values = explainer.shap_values(Xp)
                except Exception:
                    background = shap.sample(Xp, 100); explainer = shap.KernelExplainer(model.predict, background); shap_values = explainer.shap_values(Xp[:200])
                shap.summary_plot(shap_values, Xp, show=False); st.pyplot(plt.gcf(), clear_figure=True)
            except Exception as e:
                st.warning(f"SHAP skipped: {e}")

            st.subheader("📤 Export Predictions")
            preds = best_pipe.predict(preproc.transform(X))
            out_df = df.copy()
            if task=="classification" and label_mapping:
                num2human = {k:v for k,v in label_mapping.items()}
                out_df[f"prediction_{target}"] = [num2human.get(int(p), p) for p in preds]
                out_df[f"prediction_{target}_numeric"] = preds
            else:
                out_df[f"prediction_{target}"] = preds
            buf = BytesIO(); out_df.to_csv(buf, index=False)
            st.download_button("Download predictions CSV", data=buf.getvalue(), file_name="predictions.csv", mime="text/csv")

with tab2:
    st.header("StudySync – Group Study Tracker")
    st.caption("JSON storage + matplotlib charts")
    import json as _json
    colA, colB = st.columns([2,1])
    with colA:
        user = st.text_input("Name", value=st.session_state.get("last_user",""))
        d = st.date_input("Date", value=date.today())
        hours = st.number_input("Hours", min_value=0.0, max_value=24.0, step=0.5)
        goal = st.text_input("Goal / Topic (optional)")
        if st.button("Add entry"):
            if not user.strip(): st.warning("Enter a name.")
            else:
                st.session_state["last_user"]=user.strip(); add_entry(user=user.strip(), date=d.isoformat(), hours=hours, goal=goal); st.success("Saved!")
    with colB:
        if st.button("Load demo data"):
            demo = _json.loads((Path("app")/"studysync_demo.json").read_text(encoding="utf-8")); from src.studysync.storage import save as ss_save, DEFAULT_PATH as SS_PATH; ss_save(demo, SS_PATH); st.success("Demo data loaded.")
        if st.button("Clear all data"):
            clear_all(); st.warning("All entries cleared.")
    entries = list_entries(); df2 = as_dataframe(entries)
    st.dataframe(df2.sort_values("date", ascending=False), use_container_width=True)
    if not df2.empty:
        fig1, ax1 = plt.subplots(figsize=(6,3)); df2.groupby("user")["hours"].sum().sort_values(ascending=False).plot(kind="bar", ax=ax1); ax1.set_title("Total Hours by User"); ax1.set_ylabel("Hours"); st.pyplot(fig1)
        wk = df2.groupby(["year","week"])["hours"].sum().reset_index(); wk["wk_label"]=wk["year"].astype(str)+"-W"+wk["week"].astype(str)
        fig2, ax2 = plt.subplots(figsize=(7,3)); ax2.plot(wk["wk_label"], wk["hours"], marker="o"); ax2.set_title("Weekly Group Study Hours"); ax2.set_xlabel("Week"); ax2.set_ylabel("Hours"); import matplotlib.pyplot as _plt; _plt.setp(ax2.get_xticklabels(), rotation=45, ha="right"); st.pyplot(fig2)
        users = sorted(df2["user"].unique().tolist())
        if users:
            pick = st.selectbox("User trend", options=users); dfx = df2[df2["user"]==pick].groupby("date")["hours"].sum().reset_index()
            fig3, ax3 = plt.subplots(figsize=(7,3)); ax3.plot(dfx["date"], dfx["hours"], marker="o"); ax3.set_title(f"Daily Hours – {pick}"); ax3.set_xlabel("Date"); ax3.set_ylabel("Hours"); _plt.setp(ax3.get_xticklabels(), rotation=45, ha="right"); st.pyplot(fig3)
    else:
        st.info("No entries yet. Add some above or load demo data.")


import json
from pathlib import Path
import joblib
def save_json(obj, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f: json.dump(obj, f, indent=2)
def load_json(path: Path):
    with open(path, "r", encoding="utf-8") as f: return json.load(f)
def save_joblib(obj, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True); joblib.dump(obj, path)
def load_joblib(path: Path): return joblib.load(path)

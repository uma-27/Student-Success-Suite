
from typing import List
import pandas as pd, numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split
def split_features_target(df: pd.DataFrame, target: str):
    X, y = df.drop(columns=[target]), df[target]; return X, y
def infer_task(y: pd.Series) -> str:
    import pandas as pd
    return "regression" if pd.api.types.is_numeric_dtype(y) and y.nunique()>10 else "classification"
def detect_column_types(X: pd.DataFrame):
    numeric_cols = X.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = [c for c in X.columns if c not in numeric_cols]
    return numeric_cols, categorical_cols
def build_preprocessor(numeric_cols: List[str], categorical_cols: List[str]):
    return ColumnTransformer([("num", StandardScaler(), numeric_cols), ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), categorical_cols)])
def train_val_split(X, y, test_size=0.2, random_state=42, stratify=True):
    import pandas as pd
    if stratify and len(pd.Series(y).unique())>1: return train_test_split(X, y, test_size=test_size, random_state=random_state, stratify=y)
    return train_test_split(X, y, test_size=test_size, random_state=random_state)


import argparse, json
from pathlib import Path
import pandas as pd, numpy as np
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import cross_val_score
from sklearn.metrics import accuracy_score, f1_score, r2_score, mean_absolute_error, mean_squared_error
from sklearn.preprocessing import LabelEncoder
from xgboost import XGBClassifier, XGBRegressor
from .config import DEFAULT_MODEL_PATH, DEFAULT_PREPROCESSOR_PATH, DEFAULT_META_PATH, DEFAULT_REPORT_PATH
from .data_prep import split_features_target, detect_column_types, build_preprocessor, train_val_split, infer_task
from .utils import save_joblib, save_json

def choose_models(task):
    if task=="classification":
        return {
            "logreg": LogisticRegression(max_iter=500),
            "rf": RandomForestClassifier(n_estimators=300, random_state=42),
            "xgb": XGBClassifier(n_estimators=400, learning_rate=0.05, max_depth=6, subsample=0.9, colsample_bytree=0.9, reg_lambda=1.0, random_state=42, eval_metric="logloss")
        }
    return {
        "linreg": LinearRegression(),
        "rf": RandomForestRegressor(n_estimators=300, random_state=42),
        "xgb": XGBRegressor(n_estimators=400, learning_rate=0.05, max_depth=6, subsample=0.9, colsample_bytree=0.9, reg_lambda=1.0, random_state=42)
    }

def main(args):
    df = pd.read_csv(args.data)
    X, y = split_features_target(df, args.target)
    task = args.task or infer_task(y)

    label_mapping=None
    if task=="classification" and (y.dtype=="O" or str(y.dtype).startswith("category")):
        le = LabelEncoder(); y = pd.Series(le.fit_transform(y), index=y.index)
        label_mapping = {int(i): cls for i, cls in enumerate(le.classes_)}

    num_cols, cat_cols = detect_column_types(X)
    preprocessor = build_preprocessor(num_cols, cat_cols)
    X_train, X_test, y_train, y_test = train_val_split(X, y, test_size=args.test_size, stratify=(task=="classification"))

    models = choose_models(task)
    best_name, best_score, best_pipe = None, -np.inf, None
    results=[]
    for name, model in models.items():
        pipe = Pipeline([("prep", preprocessor), ("model", model)])
        scoring = "f1_macro" if task=="classification" else "r2"
        scores = cross_val_score(pipe, X_train, y_train, cv=5, scoring=scoring)
        score = float(scores.mean()); results.append({"model":name, "cv_score":score})
        if score>best_score: best_name, best_score, best_pipe = name, score, pipe

    best_pipe.fit(X_train, y_train)

    if task=="classification":
        y_pred = best_pipe.predict(X_test)
        metrics={"accuracy": float(accuracy_score(y_test, y_pred)), "f1_macro": float(f1_score(y_test, y_pred, average="macro"))}
    else:
        y_pred = best_pipe.predict(X_test)
        metrics={"r2": float(r2_score(y_test, y_pred)), "mae": float(mean_absolute_error(y_test, y_pred)), "rmse": float(mean_squared_error(y_test, y_pred, squared=False))}

    save_joblib(best_pipe.named_steps["model"], Path(args.model_path or DEFAULT_MODEL_PATH))
    save_joblib(best_pipe.named_steps["prep"], Path(args.preproc_path or DEFAULT_PREPROCESSOR_PATH))
    save_json({
        "task": task, "best_model": best_name, "cv_results": results,
        "feature_groups": {"numeric": num_cols, "categorical": cat_cols},
        "target": args.target, "label_mapping": label_mapping
    }, Path(args.meta_path or DEFAULT_META_PATH))
    save_json({"metrics": metrics, "model": best_name, "task": task, "test_size": args.test_size}, Path(args.report_path or DEFAULT_REPORT_PATH))

    print("Training complete. Best model:", best_name); print("Metrics:", json.dumps(metrics, indent=2))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str, required=True)
    parser.add_argument("--target", type=str, required=True)
    parser.add_argument("--task", type=str, choices=["classification","regression"], default=None)
    parser.add_argument("--test_size", type=float, default=0.2)
    parser.add_argument("--model_path", type=str, default=None)
    parser.add_argument("--preproc_path", type=str, default=None)
    parser.add_argument("--meta_path", type=str, default=None)
    parser.add_argument("--report_path", type=str, default=None)
    args = parser.parse_args(); main(args)


import argparse
from pathlib import Path
import pandas as pd
from sklearn.metrics import classification_report, confusion_matrix, r2_score, mean_absolute_error, mean_squared_error
from .utils import load_joblib, load_json
from .config import DEFAULT_MODEL_PATH, DEFAULT_PREPROCESSOR_PATH, DEFAULT_META_PATH

def main(args):
    model = load_joblib(Path(args.model_path or DEFAULT_MODEL_PATH))
    preproc = load_joblib(Path(args.preproc_path or DEFAULT_PREPROCESSOR_PATH))
    meta = load_json(Path(args.meta_path or DEFAULT_META_PATH))

    df = pd.read_csv(args.data)
    X = df.drop(columns=[meta["target"]])
    y = df[meta["target"]]

    Xp = preproc.transform(X)

    if meta["task"] == "classification":
        y_pred = model.predict(Xp)
        print(classification_report(y, y_pred))
        print("Confusion Matrix:\n", confusion_matrix(y, y_pred))
    else:
        y_pred = model.predict(Xp)
        print("R2:", r2_score(y, y_pred))
        print("MAE:", mean_absolute_error(y, y_pred))
        print("RMSE:", mean_squared_error(y, y_pred, squared=False))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str, required=True)
    parser.add_argument("--model_path", type=str, default=None)
    parser.add_argument("--preproc_path", type=str, default=None)
    parser.add_argument("--meta_path", type=str, default=None)
    args = parser.parse_args(); main(args)


import argparse
from pathlib import Path
import pandas as pd, shap, numpy as np
from .utils import load_joblib, load_json
from .config import DEFAULT_MODEL_PATH, DEFAULT_PREPROCESSOR_PATH, DEFAULT_META_PATH

def main(args):
    model = load_joblib(Path(args.model_path or DEFAULT_MODEL_PATH))
    preproc = load_joblib(Path(args.preproc_path or DEFAULT_PREPROCESSOR_PATH))
    meta = load_json(Path(args.meta_path or DEFAULT_META_PATH))

    df = pd.read_csv(args.data)
    X = df.drop(columns=[meta["target"]])
    Xp = preproc.transform(X)

    try:
        explainer = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(Xp)
        print("Computed SHAP values with TreeExplainer.")
    except Exception as e:
        print("TreeExplainer failed, using KernelExplainer:", str(e))
        background = shap.sample(Xp, 100)
        explainer = shap.KernelExplainer(model.predict, background)
        shap_values = explainer.shap_values(Xp[:100])

    out = Path(args.out_path or "reports/shap_values.npy")
    out.parent.mkdir(parents=True, exist_ok=True)
    np.save(out, shap_values if isinstance(shap_values, np.ndarray) else np.array(shap_values, dtype=object))
    print(f"Saved SHAP values to {out}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str, required=True)
    parser.add_argument("--model_path", type=str, default=None)
    parser.add_argument("--preproc_path", type=str, default=None)
    parser.add_argument("--meta_path", type=str, default=None)
    parser.add_argument("--out_path", type=str, default=None)
    args = parser.parse_args(); main(args)

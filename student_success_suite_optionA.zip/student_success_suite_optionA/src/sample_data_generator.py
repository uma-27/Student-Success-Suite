
import numpy as np, pandas as pd
from pathlib import Path
rng = np.random.default_rng(42)
N=1200
study_hours = rng.normal(2.5,1.0,N).clip(0,6)
absences = rng.poisson(3,N)
parent_edu = rng.choice(['none','highschool','bachelor','master'], size=N, p=[0.1,0.45,0.35,0.1])
internet = rng.choice(['yes','no'], size=N, p=[0.85,0.15])
gender = rng.choice(['male','female'], size=N, p=[0.48,0.52])
participation = rng.integers(0,11,N)
past_failures = rng.integers(0,4,N)
gpa_prev = (rng.normal(2.6,0.6,N)).clip(0,4)
score = 0.9*study_hours -0.3*absences +0.2*participation -0.5*past_failures +0.6*gpa_prev + ( (parent_edu=='bachelor')*0.2 + (parent_edu=='master')*0.35 ) + ((internet=='yes')*0.15 - (internet=='no')*0.1) + rng.normal(0,0.8,N)
final_grade = (score*2.5 + 50).clip(0,100)
passed = (final_grade>=60).astype(int)
df = pd.DataFrame({
  "study_hours":study_hours,"absences":absences,"parent_edu":parent_edu,"internet":internet,"gender":gender,
  "participation":participation,"past_failures":past_failures,"gpa_prev":gpa_prev,"final_grade":final_grade.round(1),"passed":passed
})
out = Path(__file__).resolve().parents[1]/"data"/"sample_students.csv"
out.parent.mkdir(parents=True, exist_ok=True); df.to_csv(out,index=False); print("Wrote", out)

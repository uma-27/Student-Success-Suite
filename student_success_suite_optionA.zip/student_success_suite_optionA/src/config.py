
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"
REPORTS_DIR = BASE_DIR / "reports"
DEFAULT_MODEL_PATH = MODELS_DIR / "model.joblib"
DEFAULT_PREPROCESSOR_PATH = MODELS_DIR / "preprocessor.joblib"
DEFAULT_META_PATH = MODELS_DIR / "meta.json"
DEFAULT_REPORT_PATH = REPORTS_DIR / "training_report.json"

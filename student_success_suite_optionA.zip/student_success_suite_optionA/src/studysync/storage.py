
from pathlib import Path
from typing import List, Dict, Any
import json
from dataclasses import dataclass, asdict
from datetime import datetime

DEFAULT_PATH = Path(__file__).resolve().parents[2] / "data" / "studysync.json"

@dataclass
class StudyEntry:
    user: str
    date: str
    hours: float
    goal: str = ""

def _ensure_file(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists(): path.write_text(json.dumps({"entries":[]}, indent=2), encoding="utf-8")

def load(path: Path = DEFAULT_PATH) -> Dict[str, Any]:
    _ensure_file(path); return json.loads(Path(path).read_text(encoding="utf-8"))

def save(payload: Dict[str, Any], path: Path = DEFAULT_PATH) -> None:
    _ensure_file(path); Path(path).write_text(json.dumps(payload, indent=2), encoding="utf-8")

def add_entry(user: str, date: str, hours: float, goal: str = "", path: Path = DEFAULT_PATH) -> Dict[str, Any]:
    payload = load(path); payload.setdefault("entries", []).append(asdict(StudyEntry(user=user.strip(), date=date, hours=float(hours), goal=goal.strip()))); save(payload, path); return payload

def list_entries(path: Path = DEFAULT_PATH) -> List[Dict[str, Any]]:
    return load(path).get("entries", [])

def clear_all(path: Path = DEFAULT_PATH) -> None:
    save({"entries":[]}, path)


import pandas as pd
from typing import List
def as_dataframe(entries: List[dict]) -> pd.DataFrame:
    if not entries: return pd.DataFrame(columns=["user","date","hours","goal","week","year"])
    df = pd.DataFrame(entries); df["date"]=pd.to_datetime(df["date"]); df["hours"]=df["hours"].astype(float)
    df["week"]=df["date"].dt.isocalendar().week.astype(int); df["year"]=df["date"].dt.isocalendar().year.astype(int); return df
